# Generated from reports/morphometrics-analysis.qmd by R/purl.R. Edit that document, not this file; changes made here are overwritten at the next render.
params <-
list(input_file = "data-raw/palmer-morphometrics-2024.csv")

## -----------------------------------------------------------------------------
#| label: setup
#| include: false

library(readr)
library(dplyr)
library(ggplot2)
library(toolero)
library(gt)
library(broom)


## -----------------------------------------------------------------------------
#| label: input-resolution

input_file <- resolve_input_path(
  interactive = "data-raw/palmer-morphometrics-2024.csv"
)

context <- detect_execution_context()
should_render_outputs <- !identical(context, "rscript")

# save_output() creates any missing folder, so none are created here.
save_plot <- function(object, file_path, ...) {
  ggplot2::ggsave(filename = file_path, plot = object, ...)
}


## -----------------------------------------------------------------------------
#| label: load-data
#| message: true

penguins <- read_csv(input_file, show_col_types = FALSE)

n_missing_cols <- sum(colSums(is.na(penguins)) > 0)
message(
  "Read ", nrow(penguins), " rows and ", ncol(penguins), " columns; ",
  n_missing_cols, " columns contain missing values."
)


## -----------------------------------------------------------------------------
#| label: fig-bill-morphometrics
#| fig-cap: "Bill length against bill depth, by species"

bill_plot <- penguins |>
  ggplot(aes(
    x = bill_length_mm,
    y = bill_depth_mm,
    color = species,
    shape = species
  )) +
  geom_point(alpha = 0.7, size = 2) +
  scale_color_brewer(palette = "Set2") +
  labs(
    title    = "Bill morphometrics by species",
    subtitle = "Palmer Station, recent field seasons",
    x        = "Bill length (mm)",
    y        = "Bill depth (mm)",
    color    = NULL,
    shape    = NULL,
    caption  = "Data: Palmer Station LTER (Gorman, Williams & Fraser 2014)"
  ) +
  theme_minimal(base_size = 13) +
  theme(legend.position = "bottom")

save_output(
  bill_plot,
  "output/figures/bill-morphometrics.png",
  .f     = save_plot,
  width  = 7,
  height = 5,
  dpi    = 300,
  note   = "The appendix figure"
)

if (should_render_outputs) bill_plot


## -----------------------------------------------------------------------------
#| label: summary

flipper_stats <- penguins |>
  group_by(species) |>
  summarize(
    min_flipper_length  = min(flipper_length_mm, na.rm = TRUE),
    max_flipper_length  = max(flipper_length_mm, na.rm = TRUE),
    mean_flipper_length = mean(flipper_length_mm, na.rm = TRUE),
    sd_flipper_length   = sd(flipper_length_mm, na.rm = TRUE),
    .groups = "drop"
  )

save_output(
  flipper_stats,
  "output/tables/flipper-stats.csv",
  .f   = write_csv,
  note = "Flipper summary statistics"
)


## -----------------------------------------------------------------------------
#| label: tbl-penguin-flipper-stats
#| tbl-cap: "Flipper statistics per species"

flipper_stats_tbl <- flipper_stats |>
  gt() |>
  fmt_number(decimals = 0) |>
  cols_label(
    species              = "Species",
    min_flipper_length   = "Minimum",
    max_flipper_length   = "Maximum",
    mean_flipper_length  = "Mean",
    sd_flipper_length    = "SD"
  ) |>
  tab_header(
    title = "Flipper length by species",
    subtitle = "Summary statistics in millimeters"
  )

if (should_render_outputs) flipper_stats_tbl


## -----------------------------------------------------------------------------
#| label: fig-flipper-length-dist
#| fig-cap: "Flipper length distribution by species"

flipper_plot <- penguins |>
  ggplot(aes(
    x = species,
    y = flipper_length_mm,
    color = species,
    fill = species
  )) +
  geom_violin(alpha = 0.15, linewidth = 0) +
  geom_boxplot(alpha = 0.4, width = 0.3, outlier.shape = NA) +
  geom_jitter(width = 0.1, alpha = 0.5, size = 1.5) +
  scale_color_brewer(palette = "Set2") +
  scale_fill_brewer(palette = "Set2") +
  labs(
    title    = "Flipper length by species",
    subtitle = "Distribution of flipper length in millimeters",
    x        = NULL,
    y        = "Flipper length (mm)",
    caption  = "Data: Palmer Station LTER (Gorman, Williams & Fraser 2014)"
  ) +
  theme_minimal(base_size = 13) +
  theme(legend.position = "none")

save_output(
  flipper_plot,
  "output/figures/flipper-length-dist.png",
  .f     = save_plot,
  width  = 7,
  height = 5,
  dpi    = 300,
  note   = "Flipper length distributions by species"
)

if (should_render_outputs) flipper_plot


## -----------------------------------------------------------------------------
#| label: fit-model
#| echo: fenced

# species_role controls how species enters the model:
#   "none"        : flipper length only
#   "additive"    : flipper length + species (parallel intercepts)
#   "interaction" : flipper length * species (separate slopes)

species_role <- "interaction"

# A per-species subset has a single level of species, and lm() cannot
# estimate a term with one level, so fall back to flipper length alone.
if (n_distinct(penguins$species) < 2) {
  species_role <- "none"
}

model_formula <- switch(species_role,
  none        = body_mass_g ~ flipper_length_mm,
  additive    = body_mass_g ~ flipper_length_mm + species,
  interaction = body_mass_g ~ flipper_length_mm * species
)

flipper_model <- lm(model_formula, data = penguins)

save_output(
  flipper_model,
  "output/flipper-model.rds",
  .f   = saveRDS,
  note = paste("The fitted model object; species role:", species_role)
)


## -----------------------------------------------------------------------------
#| label: tbl-model-coefficients
#| tbl-cap: "Estimated coefficients, body mass by flipper length"

model_coefficients <- broom::tidy(flipper_model)

save_output(
  model_coefficients,
  "output/tables/model-coefficients.csv",
  .f   = write_csv,
  note = "Model coefficient estimates"
)

model_tbl <- model_coefficients |>
  gt() |>
  fmt_number(columns = c(estimate, std.error, statistic), decimals = 2) |>
  fmt_scientific(columns = p.value, decimals = 2) |>
  cols_label(
    term      = "Term",
    estimate  = "Estimate",
    std.error = "Std. Error",
    statistic = "t statistic",
    p.value   = "p value"
  ) |>
  tab_header(
    title = "Body mass by flipper length",
    subtitle = paste("Species role:", species_role)
  )

if (should_render_outputs) model_tbl


## -----------------------------------------------------------------------------
#| label: fig-model-fit
#| fig-cap: "Fitted relationship between flipper length and body mass"

model_plot <- penguins |>
  ggplot(aes(x = flipper_length_mm, y = body_mass_g, color = species)) +
  geom_point(alpha = 0.5, size = 1.5) +
  geom_smooth(method = "lm", se = FALSE, linewidth = 1) +
  scale_color_brewer(palette = "Set2") +
  labs(
    title    = "Body mass by flipper length",
    subtitle = paste("Species role:", species_role),
    x        = "Flipper length (mm)",
    y        = "Body mass (g)",
    color    = NULL,
    caption  = "Data: Palmer Station LTER (Gorman, Williams & Fraser 2014)"
  ) +
  theme_minimal(base_size = 13) +
  theme(legend.position = "bottom")

save_output(
  model_plot,
  "output/figures/model-fit.png",
  .f     = save_plot,
  width  = 7,
  height = 5,
  dpi    = 300,
  note   = "Fitted body mass against flipper length"
)

if (should_render_outputs) model_plot


## -----------------------------------------------------------------------------
#| label: output-record

generate_manifest(overwrite = TRUE)


## -----------------------------------------------------------------------------
#| label: tbl-output-record
#| tbl-cap: "What this document produced, from its output record"

if (should_render_outputs) {
  read_output_records() |>
    select(file_path, function_used, status, note) |>
    gt() |>
    cols_label(
      file_path     = "File",
      function_used = "Written with",
      status        = "Status",
      note          = "What it is"
    )
}


## -----------------------------------------------------------------------------
#| label: tbl-where-this-ran
#| tbl-cap: "Where this document ran"

if (should_render_outputs) {
  tibble(
    item  = c("Execution context", "Operating system", "R version", "Run at"),
    value = c(
      context,
      paste(Sys.info()[["sysname"]], Sys.info()[["release"]]),
      R.version.string,
      format(Sys.time(), "%Y-%m-%d %H:%M %Z")
    )
  ) |>
    gt() |>
    tab_options(column_labels.hidden = TRUE)
}

